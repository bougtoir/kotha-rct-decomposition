---
running_head: KOTHA Framework for Trial Design
title: The KOTHA Framework: Diagnosing Structural Information Loss in Randomized Controlled Trial Meta-Analyses to Inform Trial Design
authors: [To be determined]
affiliations: [To be determined]
word_count: 2682
corresponding_author: [To be determined]
corresponding_author_address: [To be determined]
---
## Abstract

**Background/Aims**: Evidence-based medicine places RCTs and meta-analyses at the top of the evidence hierarchy, yet when observational and RCT evidence disagree the usual explanation is residual confounding. We highlight a structural explanation: trial enrollment progressively excludes higher-risk patients, diluting event rates and statistical information. The Knowledge-driven Observational-Trial Harmonization Approach (KOTHA) Framework diagnoses this structural information loss. We aimed to develop and illustrate KOTHA so that trialists can distinguish structural information loss from residual confounding and inform sample size, eligibility, enrichment, and endpoint decisions in prospective trial design.

**Methods**: KOTHA comprises three modules: Module K quantifies risk-profile shifts and power loss, Module T combines RCT and observational evidence with power-prior discounting, and Module H translates outputs into a GRADE-compatible assessment. We applied it to magnesium in acute myocardial infarction and statins in heart failure.

**Results**: In the magnesium case, control event rates fell from 8.9% to 7.2%; the pre-ISIS-4 pooled odds ratio (OR) was 0.54 (95% CI: 0.40-0.75) and the all-trials estimate 0.56 (0.38-0.83) with $I^2$ = 62%. In the statins case, observational hazard ratio (HR) was 0.72 (0.64-0.80) versus RCT HR 0.97 (0.90-1.05), with an event-rate ratio of 0.51. Bayesian integration (alpha = 0.3) yielded OR 0.74 (CrI 0.25-1.43), P(OR < 1) = 80.7% for magnesium and HR 0.85 (0.55-1.24), P(HR < 1) = 86.5% for statins; both probabilities remained below conventional decision thresholds, leaving conclusions uncertain.

**Conclusions**: KOTHA distinguishes "evidence of no effect" from "no evidence of effect". Module H classified magnesium as inconclusive with serious inconsistency (heterogeneity), and statins as inconclusive with serious indirectness.

**Keywords**: randomized controlled trials, meta-analysis, observational studies, trial design, Bayesian evidence synthesis, GRADE

## Abbreviations

* **ADEMP**: Aims, Data-generating mechanisms, Estimands, Methods, Performance measures
* **AMI**: Acute myocardial infarction
* **CrI**: Credible interval
* **CI**: Confidence interval
* **GRADE**: Grading of Recommendations Assessment, Development and Evaluation
* **HF**: Heart failure
* **HR**: Hazard ratio
* **KOTHA**: Knowledge-driven Observational-Trial Harmonization Approach
* **MCMC**: Markov chain Monte Carlo
* **OIS**: Optimal information size
* **OR**: Odds ratio
* **RCT**: Randomized controlled trial
* **TSA**: Trial sequential analysis

## 1. Introduction

Evidence-based medicine places RCTs and their meta-analyses at the apex of the evidence hierarchy because randomization minimizes confounding and provides internally valid estimates of treatment effects [1]. Nevertheless, meta-analyses of observational studies and RCTs frequently disagree: observational evidence may show statistically significant benefit while RCT evidence does not [2-3]. The conventional explanation invokes residual confounding, selection bias, or publication bias in observational data. While these sources of bias are real, they may not fully account for the discordance.

An alternative structural explanation deserves systematic attention. RCT enrollment criteria, consent processes, and site selection progressively restrict the study population [4-5]. Because clinical events are concentrated in the highest-risk patients---those with comorbidities, advanced disease, or organ dysfunction---their exclusion lowers event rates in the enrolled cohort. If trial protocols do not compensate by increasing sample size, extending follow-up, or enriching high-risk enrollment, the resulting evidence base can become informationally insufficient. We call this phenomenon **structural information loss**, a five-step causal chain: representativeness loss; event concentration in excluded populations; inadequate design compensation; systematic underpowering; and, ultimately, distorted recommendations when "no statistically significant difference" is interpreted as "no effect".

The concepts of optimal information size (OIS) and trial sequential analysis (TSA) provide partial remedies. OIS recognizes that meta-analyses, like individual trials, require a minimum information size to reach reliable conclusions [6-7]. TSA applies sequential monitoring boundaries to cumulative meta-analysis, distinguishing evidence of no effect (futility boundary crossed) from no evidence of effect (boundary not crossed) [8-9]. Both are underused in guideline development, however, and neither directly quantifies the information loss produced by enrollment-driven risk-profile shifts.

Several trial design strategies can mitigate event dilution (Supplementary Table S1), including stratified randomization, prognostic enrichment, event-driven designs, adaptive sample-size re-estimation, and pragmatic or registry-based trials. Existing approaches address these issues separately; to our knowledge, no widely adopted framework tightly links prospective power assessment, retrospective diagnostic evaluation, and structured evidence interpretation in a single reproducible workflow for completed or planned RCTs.

To address this gap we developed the Knowledge-driven Observational-Trial Harmonization Approach (KOTHA). The framework has three modules: Module K diagnoses structural information loss through counterfactual power simulation; Module T integrates discordant evidence through hierarchical Bayesian meta-analysis; and Module H translates quantitative findings into a GRADE-compatible evidence assessment. We describe the framework here and illustrate it with two canonical cases of observational-RCT divergence, focusing on implications for clinical trial design.

## 2. Methods

### Overview

The KOTHA Framework comprises three interconnected modules (Fig. 1). Module K (Counterfactual Power Simulation) quantifies how enrollment-driven risk-profile shifts reduce statistical power. Module T (Trial-Observational Bayesian Integration) combines RCT and observational evidence with explicit discounting for design-related bias. Module H (Guideline Interpreter) translates module outputs into a structured GRADE assessment. Each module can be used independently, but the framework is most informative when applied in sequence.

**Fig. 1** Overview of the KOTHA Framework. Module K (Counterfactual Power Simulation) quantifies risk-profile shift and estimates power under counterfactual enrollment scenarios. Module T (Bayesian Evidence Integration) combines RCT and observational evidence using power-prior discounting. Module H (Guideline Interpreter) synthesizes outputs into a structured GRADE-compatible assessment.

![Fig. 1](validation/figures/fig1_framework_overview.png)

### Module K: Counterfactual power simulation

Module K asks: if the RCTs in a meta-analysis had enrolled patients with the risk profile of the real-world target population, would the combined evidence have been sufficient to detect the effect suggested by observational studies? The simulation component follows the ADEMP reporting structure [10]: aims (quantify information loss from enrollment-driven risk-profile shifts), data-generating process (published aggregate event counts and sample sizes), estimands (counterfactual power under S1-S3), methods (Schoenfeld approximation with proportional-hazards data handled via the log-HR/log-OR equivalence under rare events), and performance measures (power across a grid of true effects and required sample size).

We define three enrollment scenarios: S1 (real-world target population, approximated by a representative retrospective cohort or published aggregate event rates); S2 (RCT-enrolled equivalent, defined by applying published eligibility criteria to the retrospective cohort or using observed RCT event rates); and S3 (design-optimized, incorporating prognostic enrichment).

For each scenario, we compute the expected control event rate $p_c$ and treatment event rate $p_t = (p_c \cdot \text{OR}) / (1 - p_c + p_c \cdot \text{OR})$. The total expected number of events is $D = N(p_c + p_t)/2$ for a trial of $N$ patients randomized 1:1. Under the Schoenfeld approximation [11], the standard error of the log relative effect (log-OR or log-HR under proportional hazards) is approximately $2/\sqrt{D}$, yielding the power function

$$\text{Power} = \Phi\left( |\log(\text{OR or HR})| \cdot \sqrt{D} / 2 - z_{\alpha/2} \right)$$

where $\Phi$ is the standard normal cumulative distribution function. The ratio $\rho = p_c^{(S2)} / p_c^{(S1)}$ quantifies event dilution. Module K reports power across a grid of assumed true effects and computes the sample size required to reach 80% power under each scenario. For the statins case, which reports hazard ratios, the hazard ratio is approximated by an odds ratio under the rare-event assumption and crude control event proportions derived from the aggregate data are used as approximate event probabilities; this comparison is intended to illustrate the relative power loss across enrollment scenarios rather than to provide exact sample-size estimates for a specific follow-up duration.

### Module T: Hierarchical Bayesian evidence integration

When Module K indicates that RCT evidence is informationally insufficient, Module T combines RCT and observational evidence while discounting the observational likelihood for potential design-specific bias. Let $y_i$ denote the reported log effect size from study $i$ with standard error $s_i$. The RCT evidence contributes its full likelihood; the observational evidence contributes a power-prior-discounted likelihood with factor $\alpha \in [0, 1]$ [12], so that $\alpha = 0$ retains only RCTs and $\alpha = 1$ gives observational data full weight. Between-study heterogeneity is modeled with a random-effects distribution $u_i \sim \text{Normal}(0, \tau^2)$. We used weakly informative priors $\mu \sim N(0, 10^2)$ on the population mean log effect and $\tau \sim \text{Half-Cauchy}(0, 0.5)$ on the between-study standard deviation, with $\tau$ bounded between $10^{-9}$ and $100$ for numerical stability. Alternative effect measures such as restricted mean survival time can be substituted when proportional-hazards assumptions are questionable [13-14]. Evidence-based priors have been proposed to anchor historical expectations while limiting prior-data conflict [15]. We also present bias-adjusted normal-approximation analyses as a sensitivity check. Posterior distributions are sampled with an affine-invariant ensemble MCMC [16] using 16 walkers, 1,000 warmup and 4,000 post-warmup iterations per walker, for each $\alpha$ in $(0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0)$. Convergence was assessed with split-R-hat and effective sample size (ESS) for the population mean log effect and the between-study heterogeneity, using accepted thresholds (split-R-hat < 1.05; ESS per parameter > 400). Trace plots for selected chains are provided as Supplementary Figures S1a (magnesium) and S1b (statins) and showed no obvious non-stationarity. Across all discounting factors the minimum ESS was 972 and the maximum split-R-hat was 1.024, both satisfying the convergence criteria. We report the full grid to show sensitivity and use $\alpha$ = 0.3 as an illustrative moderate-discounting value without claiming it is universally optimal.

### Module H: Guideline interpretation

Module H maps the outputs of Modules K and T onto the GRADE framework [1]. It includes five assessments (Table 1): information sufficiency (OIS vs observed events), confidence interval interpretation, representativeness (event rate ratio), TSA boundary status, and recommended language. For CI interpretation, we used relative effect boundaries of 0.80 and 1.25 to define clinically important benefit and harm. For representativeness, event-rate ratios below 0.67 or above 1.50 (a relative shift of 50% or more) are classified as serious indirectness, and ratios below 0.80 or above 1.25 (a relative shift of 25% or more) as moderate indirectness. These thresholds correspond to conventional boundaries for clinically important relative effects. The result is a KOTHA-enhanced certainty rating and recommendation that explicitly distinguishes "evidence of effect," "evidence of no effect," and "no evidence of effect (inconsistent or indirect).

**Table 1: Module H assessment checklist mapped to GRADE domains**

| Module H assessment | GRADE domain | Analytical tool | Decision criterion |
|---|---|---|---|
| Information sufficiency | Imprecision | OIS calculation | Total events < OIS: informationally insufficient |
| CI assessment | Imprecision | CI inspection | CI spans benefit through null: inconclusive |
| Representativeness | Indirectness | Module K event rate ratio | < 0.67 or > 1.50: serious; < 0.80 or > 1.25: moderate |
| TSA | Imprecision | Sequential monitoring boundaries | Boundaries not crossed: interim analysis equivalent |
| Recommendation language | Overall assessment | Standardized templates | Tailored to information sufficiency classification |

### Data sources and statistical analysis

For magnesium in AMI we used study-level event counts extracted from published overviews [17-18]. For statins in heart failure we used aggregate data from five observational cohorts [19-23] and two RCTs [24-25]. We used DerSimonian-Laird random-effects meta-analysis [26] and computed 95% confidence intervals. OIS and TSA were calculated using standard formulas [6-9]. All analyses were performed with the Python code in the public repository.

## 3. Results

### Study-level data and risk-profile shift

Study-level data are provided in Supplementary Table S2 (magnesium in AMI) and Supplementary Table S3 (statins in HF). In the magnesium case, control-group mortality fell from a pre-thrombolysis weighted mean of 8.9% to 7.2% in ISIS-4, an event rate ratio of 0.82 (Fig. 2). In the statins case, the RCT-to-observational event rate ratio was 0.51, indicating that the RCT populations had roughly half the mortality event rate of the observational cohorts.

**Fig. 2** Risk-profile shift in the magnesium-in-AMI case. (A) Control-group mortality rates over time, with bubble size proportional to study sample size and colors indicating era. (B) Weighted mean control mortality by era.

![Fig. 2](validation/figures/fig2_risk_profile_shift.png)

### Counterfactual power simulation

At the ISIS-4 sample size (N = 58,050) and the pre-ISIS-4 pooled effect (OR = 0.54), power exceeded 99% under all three event-rate scenarios. For a more modest effect (OR = 0.90), however, power was 95.8% under the pre-thrombolysis rate and 91.5% under the ISIS-4 rate (Fig. 3A). For statins, power to detect the observational effect (HR = 0.72) was 100.0% under the observational event rate and 100.0% under the RCT event rate; for a more modest effect (HR = 0.85), power fell from 98.4% to 83.2%---a 15 percentage-point reduction consistent with event dilution (Fig. 3B).

**Fig. 3** Estimated power by enrollment scenario and true effect size. (A) Magnesium in AMI at the ISIS-4 sample size (N = 58,050). (B) Statins in HF at the combined RCT sample size (N = 9,585). S1 = real-world/observational event rate; S2 = RCT event rate; S3 = intermediate/enriched rate. Horizontal dashed lines indicate 80% power.

![Fig. 3](validation/figures/fig3_power_curves.png)

### Frequentist meta-analysis and trial sequential analysis

Fig. 4 shows forest plots for magnesium and statins. Random-effects meta-analysis of the 11 pre-ISIS-4 magnesium trials yielded OR = 0.54 (95% CI: 0.40-0.75) with $I^2$ = 6%. Adding ISIS-4 changed the pooled estimate to OR = 0.56 (0.38-0.83), but heterogeneity increased to $I^2$ = 62% (Fig. 4A). Under fixed-effect accumulation the final cumulative $Z$ was 0.80, which did not cross the conventional two-sided boundary for benefit or harm ($|Z|$ = 1.96); under random-effects accumulation the final $Z$ was -2.90, crossing the lower O'Brien-Fleming boundary of -1.96. Because cumulative information exceeded the optimal information size, this boundary equals the conventional two-sided boundary (Supplementary Fig. S2). This divergence is consistent with era-dependent treatment-effect heterogeneity, with the ISIS-4 result contributing substantially to that heterogeneity.

For statins, observational studies showed a pooled HR of 0.72 (95% CI: 0.64-0.80) with $I^2$ = 82%, whereas the two RCTs (CORONA and GISSI-HF) yielded HR = 0.97 (0.90-1.05) with $I^2$ = 0% (Fig. 4B).

**Fig. 4** Forest plots for (A) magnesium in AMI and (B) statins in heart failure. Individual study effect estimates are shown with 95% confidence intervals. Pooled estimates include frequentist random-effects and Bayesian integrated estimates at selected discounting levels ($\alpha$ = 0.3, 0.5, 1.0 for magnesium; 0.1, 0.3, 0.5 for statins).

![Fig. 4](validation/figures/fig4_forest_combined.png)

### Bayesian integration

Bayesian integration (Supplementary Table S4) showed that for magnesium, with $\alpha$ = 0 (ISIS-4 only), the posterior median OR was 1.05 with 42.8% probability of benefit. With $\alpha$ = 0.3 the posterior shifted to OR = 0.74 (95% CrI: 0.25-1.43), with 80.7% probability of benefit (Supplementary Fig. S3A). For statins, with $\alpha$ = 0 (RCTs only) the posterior probability of benefit was 62.9% and the probability of a clinically meaningful benefit (HR < 0.90) was 21.2%. With $\alpha$ = 0.3 these probabilities rose to 86.5% and 66.0%, respectively (Supplementary Fig. S3B). Even with moderate borrowing from observational evidence, conclusions remained uncertain.

### Module H assessment

Module H results are summarized in Table 2 and Supplementary Fig. S4. For magnesium, the OIS for the pre-ISIS-4 effect was 85 events and the observed total was 4,617 (information fraction 5426%). The TSA efficacy boundary was crossed under random-effects accumulation, but the pooled estimate was dominated by high between-study heterogeneity ($I^2$ = 62%). The appropriate KOTHA classification is **Inconclusive with serious inconsistency (heterogeneity)** (TSA/CI indicate benefit but the signal is downgraded by serious inconsistency (heterogeneity)). For statins, if the observational effect (HR 0.72) represented the true effect in the target population, the required information size would be 279 events; the RCTs contributed 1,385 events (information fraction 496%). The cumulative $Z$ was -0.74, the efficacy boundary was not crossed, and the event rate ratio was 0.51; the appropriate classification is **Inconclusive with serious indirectness** (OIS reached but no TSA/CI boundary crossed; serious indirectness from enrollment-driven event dilution). In both cases, standard GRADE would be more likely to conclude "no benefit demonstrated," whereas KOTHA explicitly labels the evidence as informationally insufficient.

**Table 2: Module H assessment --- Standard GRADE vs. KOTHA-enhanced**

| GRADE domain | Standard (Mg in AMI) | KOTHA (Mg in AMI) | Standard (Statins HF) | KOTHA (Statins HF) |
|---|---|---|---|---|
| Risk of bias | Low | Low | Low | Low |
| Inconsistency | High ($I^2$ = 62%) | High ($I^2$ = 62%) | Low ($I^2$ = 0%) | Low ($I^2$ = 0%) |
| Indirectness | Not assessed | Low: event rate decreased by 18% | Not assessed | Serious: event rate decreased by 49% |
| Imprecision | Not serious (OIS met) | Not serious (OIS met, CI excludes null) | Not serious (OIS met, CI excludes clinically important benefit) | Not serious (OIS met, CI excludes clinically important benefit) |
| Overall certainty | Low | Low | High | Low |
| Recommendation | "No benefit demonstrated" | "Inconclusive; conditional recommendation" | "No benefit demonstrated" | "Inconclusive; conditional recommendation" |

## 4. Discussion

### Principal findings

The KOTHA Framework integrates counterfactual power simulation, Bayesian evidence synthesis, and structured GRADE interpretation to diagnose structural information loss in RCT meta-analyses. In the magnesium case, Module K identified an 18% relative decline in control event rates from the pre-thrombolysis era to ISIS-4. The divergence between pre-ISIS-4 and all-trials estimates is more consistent with era-dependent treatment effect heterogeneity ($I^2$ = 62%) than with underpowering alone. In the statins case, Module K showed that RCT populations had roughly half the event rate of observational cohorts, and that power for a modest effect (HR = 0.85) dropped from 98% to 83%. Module T showed that even modest borrowing from observational evidence materially raised the posterior probability of benefit, yet the evidence remained uncertain. Module H classified magnesium as inconclusive with serious inconsistency (heterogeneity), and statins as inconclusive with serious indirectness, rather than "evidence of no effect."

### Implications for clinical trial design

Module K has direct prospective value. Before a trial is conducted, investigators can use published or registry-derived event rates for the target population (S1), for the population expected to enroll under current eligibility criteria (S2), and for an enriched design (S3). This comparison can inform four design decisions:

- **Sample size**: required N can be calculated under S2 and S3 rather than under an assumed event rate that may not materialize.
- **Eligibility criteria**: the information cost of excluding high-risk subgroups can be quantified and balanced against safety considerations.
- **Enrichment thresholds**: a minimum proportion of high-risk patients can be prespecified and powered.
- **Endpoints and follow-up**: when the primary event rate is diluted, composite endpoints or longer follow-up can be evaluated.

This reframes the design question: instead of asking what sample size is needed under a hypothesized effect, the trialist asks what sample size is needed given the event rate that the enrolled population will actually display.

### Comparison with existing methods

Target trial emulation uses observational data to mimic a specific RCT in order to estimate a causal effect [27-28]. Module K is complementary: it does not estimate effects but quantifies the information lost due to enrollment decisions. Existing methods for combining RCT and observational evidence include hierarchical models, power priors, and meta-analytic-predictive priors [29-31]. Module T builds on these but embeds them in a broader workflow that first diagnoses the need for integration and then interprets the result through Module H. TSA and OIS are well established [6-9], but are not routinely used to quantify risk-profile shifts. GRADE provides domains for assessment [1]; KOTHA provides quantitative inputs to the imprecision and indirectness domains without changing GRADE's structure.

### Strengths and limitations

The framework is reproducible from published aggregate data, follows the ADEMP reporting structure [10], and is illustrated with real, well-documented cases rather than synthetic examples. The modular design allows each component to be used independently.

Limitations should be acknowledged:

- The cases are retrospective applications of the framework to published aggregate data; individual patient data would strengthen risk-profile stratification and adjustment for confounders, and ecological bias may affect the representativeness assessment.
- For statins, the observational and RCT crude event proportions are aggregate study-level values, so the comparison is ecological and may not reflect within-individual risk differences.
- The hazard-ratio-to-odds-ratio approximation and the use of a crude event proportion (rather than an event rate per person-time) mean Module K estimates relative power loss across enrollment scenarios, not a definitive sample size for a specific follow-up.
- For statins, the S3 enrichment target is set at the midpoint between the observational and RCT crude proportions as an illustration; other thresholds would yield different power curves.
- The magnesium case spans the pre-thrombolysis and thrombolysis eras, so temporal changes in standard care, case mix, and outcome ascertainment create treatment-era confounding that cannot be fully controlled with aggregate data.
- Prospective validation against trials whose results are not yet known would be stronger.
- Module T treats the discounting parameter $\alpha$ as a fixed sensitivity parameter and is therefore sensitive to assumptions about residual confounding; we present the full grid of values but do not claim a single preferred $\alpha$.
- The magnesium case involves genuine treatment-effect heterogeneity across thrombolysis eras, which Module K identifies but cannot fully explain.
- Finally, adoption by guideline groups will require institutional change beyond the method itself.

## 5. Conclusions

The KOTHA Framework (Knowledge-driven Observational-Trial Harmonization Approach) diagnoses structural information loss in RCT meta-analyses through counterfactual power simulation, hierarchical Bayesian evidence integration, and structured GRADE-compatible interpretation. Empirical application to magnesium in AMI and statins in heart failure demonstrates that the framework can identify enrollment-driven event dilution, quantify its impact on statistical power, and produce more nuanced evidence assessments than standard approaches. By translating these diagnostics into prespecified sample size, eligibility, enrichment, and endpoint decisions, KOTHA offers a reproducible design aid for future clinical trials.

## Declarations

### Ethics approval and consent to participate

Not applicable. This study proposes a methodological framework and uses only published aggregate data.

### Consent for publication

Not applicable.

### Availability of data and materials

All data are from published sources and are included in the repository (https://github.com/bougtoir/kotha-rct-decomposition). Python code that reproduces all results, tables, and figures is available in the same repository.

### Trial registration

Not applicable. This manuscript presents a methodological framework and retrospective case illustrations; no prospective clinical trial was conducted.

### Declaration of competing interest

[To be determined]

### Funding source

[To be determined]

### Authors' contributions

[To be determined]

### Acknowledgements

[To be determined]

## References

1. Guyatt GH, Oxman AD, Vist GE, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ 2008; 336(7650): 924-6.
2. Concato J, Shah N and Horwitz RI. Randomized, controlled trials, observational studies, and the hierarchy of research designs. N Engl J Med 2000; 342(25): 1887-92.
3. Anglemyer A, Horvath HT and Bero L. Healthcare outcomes assessed with observational study designs compared with those assessed in randomized trials. Cochrane Database Syst Rev 2014; (4): MR000034.
4. Kennedy-Martin T, Curtis S, Faries D, et al. A literature review on the representativeness of randomized controlled trial samples and implications for the external validity of trial results. Trials 2015; 16: 495.
5. Rothwell PM. External validity of randomised controlled trials: "to whom do the results of this trial apply?" Lancet 2005; 365(9453): 82-93.
6. Pogue JM and Yusuf S. Cumulating evidence from randomized trials: utilizing sequential monitoring boundaries for cumulative meta-analysis. Control Clin Trials 1997; 18(6): 580-93.
7. Wetterslev J, Thorlund K, Brok J, et al. Estimating required information size by quantifying diversity in random-effects model meta-analyses. BMC Med Res Methodol 2009; 9: 86.
8. Brok J, Thorlund K, Gluud C, et al. Trial sequential analysis reveals insufficient information size and potentially false positive results in many meta-analyses. J Clin Epidemiol 2008; 61(8): 763-9.
9. Thorlund K, Engstrom J, Wetterslev J, et al. User manual for trial sequential analysis (TSA). Copenhagen Trial Unit, Centre for Clinical Intervention Research; 2011.
10. Morris TP, White IR and Crowther MJ. Using simulation studies to evaluate statistical methods. Stat Med 2019; 38(11): 2074-102.
11. Schoenfeld DA. Sample-size formula for the proportional-hazards regression model. Biometrics 1983; 39(2): 499-503.
12. Ibrahim JG and Chen MH. Power prior distributions for regression models. Stat Sci 2000; 15(1): 46-60.
13. McCaw ZR, Yin G and Wei LJ. Using the restricted mean survival time difference as an alternative to the hazard ratio for analyzing clinical cardiovascular studies. Circulation 2019; 140(17): 1366-8. doi:10.1161/CIRCULATIONAHA.119.040680.
14. Boyd AP, Kittelson JM and Gillen DL. Estimation of treatment effect under non-proportional hazards and conditionally independent censoring. Stat Med 2012; 31(28): 3504-15. doi:10.1002/sim.5440.
15. Sherry AD, Msaouel P, Kupferman GS, et al. Evidence-based prior for estimating the treatment effect of phase III randomized trials in oncology. JCO Precis Oncol 2024; 8: e2400363. doi:10.1200/PO.24.00363.
16. Foreman-Mackey D, Hogg DW, Lang D, et al. emcee: the MCMC hammer. Publ Astron Soc Pac 2013; 125(925): 306-12.
17. Teo KK, Yusuf S, Collins R, et al. Effects of intravenous magnesium in suspected acute myocardial infarction: overview of randomised trials. BMJ 1991; 303(6816): 1499-503.
18. Li J, Zhang Q, Zhang M, et al. Intravenous magnesium for acute myocardial infarction. Cochrane Database Syst Rev 2007; (2): CD002755.
19. Anker SD, Clark AL, Winkler R, et al. Statin use and survival in patients with chronic heart failure -- results from two observational studies with 5200 patients. Int J Cardiol 2006; 112(2): 234-42.
20. Mozaffarian D, Nye R and Levy WC. Statin therapy is associated with lower mortality among patients with severe heart failure. Am J Cardiol 2004; 93(9): 1124-9.
21. Horwich TB, MacLellan WR and Fonarow GC. Statin therapy is associated with improved survival in ischemic and non-ischemic heart failure. J Am Coll Cardiol 2004; 43(4): 642-8.
22. Go AS, Lee WY, Yang J, et al. Statin therapy and risks for death and hospitalization in chronic heart failure. JAMA 2006; 296(17): 2105-11.
23. Foody JM, Shah R, Galusha D, et al. Statins and mortality among elderly patients hospitalized with heart failure. Circulation 2006; 113(8): 1086-92.
24. Kjekshus J, Apetrei E, Barrios V, et al. Rosuvastatin in older patients with systolic heart failure. N Engl J Med 2007; 357(22): 2248-61.
25. GISSI-HF Investigators. Effect of rosuvastatin in patients with chronic heart failure (the GISSI-HF trial): a randomised, double-blind, placebo-controlled trial. Lancet 2008; 372(9645): 1231-9.
26. DerSimonian R and Laird N. Meta-analysis in clinical trials. Control Clin Trials 1986; 7(3): 177-88.
27. Hernan MA and Robins JM. Using big data to emulate a target trial when a randomized trial is not available. Am J Epidemiol 2016; 183(8): 758-64.
28. Hernan MA, Wang W and Leaf DE. Target trial emulation: a framework for causal inference from observational data. JAMA 2022; 328(24): 2446-7.
29. Schmidli H, Gsteiger S, Roychoudhury S, et al. Robust meta-analytic-predictive priors in clinical trials with historical control information. Biometrics 2014; 70(4): 1023-32.
30. Verde PE and Ohmann C. Combining randomized and non-randomized evidence in clinical research: a review of methods and applications. Res Synth Methods 2015; 6(1): 45-62.
31. Efthimiou O, Mavridis D, Debray TPA, et al. Combining randomized and non-randomized evidence in network meta-analysis. Stat Med 2017; 36(8): 1210-26.