# ResearchSquare 新バージョンアップロード用ファイル

## ファイル一覧
- `manuscript.docx`：CCT形式原稿（図表を本文にインライン配置）
- `figures/`：図1～8の個別PNGファイル（高解像度300 dpi）
- `figures.pptx`：図編集用PowerPoint
- `tables.docx`：表編集用Word
- `manuscript.md`：原稿のMarkdown版
- `data_sources.md`：データ出所

## ResearchSquare 手順
1. https://www.researchsquare.com に Springer アカウントでログイン
2. 「My Preprints」または `rs-9420092` を開く
3. 「Upload New Version」を選択
4. タイトル・著者・抄録・キーワードを最新版に更新
   - タイトル例：The KOTHA Framework: diagnosing structural information loss in randomized controlled trial meta-analyses to inform trial design
5. `manuscript.docx` をアップロード
6. 図を個別にアップロード（`figures/fig*.png`）または `figures.pptx` をアップロード
7. 「Submit」後、新バージョンの公開処理を依頼

## バージョン変更概要（コピペ用）
Updated from a methodological meta-analysis report to a trial-design implications paper formatted for Contemporary Clinical Trials. Restructured the KOTHA Framework around Modules K, T, and H, replaced hard-coded estimates with fully reproducible analyses from public data and code, and added inline figures/tables.
